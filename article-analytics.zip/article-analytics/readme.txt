=== Article analytics ===
Contributors: dguzun
Tags: post, audience, analytics
Requires at least: 3.8.1
Tested up to: 3.8.1
Stable tag: 3.8.1
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Article analytics provides digital analytics of the visitors who read your posts.

== Description ==
Article analytics provides digital analytics of the visitors who read your posts.
The following parameters can be configured:
1) Analysis period;
2) Type of audience (all visits, authenticated visits, anonymous visits);
3) Include owner visits for statistics;

== Installation ==
1. Upload article-analytics to the `/wp-content/plugins/` directory
2. Activate the plugin through the Plugins menu in WordPress
3. Set plugin parameters through the Article analytics menu in WordPress
